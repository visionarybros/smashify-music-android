# Smashify Music0.2.10

First prepared non-debug, optimized APK for public distribution. Early-stage release; latest runtime acceptance is required before publishing.

- Same signing certificate as compatible0.2.x builds, preserving in-place update compatibility.
- Non-debuggable release variant with R8 optimization. Version code12, package com.smashify.music, Android8.0+.
- No new functional UI, auth, payment or catalogue-policy changes from0.2.9.
- Retains featured-artist credits, six-card looping Home carousel, friendly offline Home, artwork-led Moto, minimum local-song length setting, locally clearable inbox and compact saved-library controls.
- Native tipping/financial transactions remain disabled. Tip on website is an explicit external-browser handoff.

Install over a compatible existing version; do not uninstall or clear app data. Saved private music is removed by uninstall/data clear, not by an intended in-place update.

Release optimization can behave differently from debug0.2.9. Before publishing, test launch/Home, sign-in retention, existing offline songs, background audio/controls, Moto and key navigation. Build/unit/static checks alone do not prove device readiness or backend/payment security.

Only publish the signed release APK and public checksum file as release assets. Do not upload debug builds, source archives, signing keys, signing configuration or passwords.
