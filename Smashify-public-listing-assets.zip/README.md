# Smashify Music for Android

**Stream Music, support artists.**

Native Android music discovery focused on African music and artists. Explore songs and artist profiles, build playlists, listen to local music, and save eligible free songs privately for listening online or offline.

## Download

Use this repository’s **Releases** page to download the signed `SmashifyMusic-…-release.apk` asset. Android8.0/API26 or newer is required. Allow installation from your chosen browser/file manager only if you trust this source.

Compatible existing Smashify0.2.x installations can update in place using the same signing certificate. Do not uninstall or clear app data to update: doing so removes private saved music and session state. A differently signed installation cannot update in place.

## Features

- Native Home, Discover, Library, Moto and Profile.
- Featured-artist credits and looping, swipeable Home banners using actual catalogue data.
- Background playback and Android media controls.
- Eligible free-song private saving without a fixed song-count quota, subject to available storage and transfer safety limits.
- Local music with an adjustable minimum-duration filter, default60 seconds.
- Artwork-led Moto with up-to30-second looping eligible free previews, not video Canvas.
- Account-linked likes/playlists, profile features and account-scoped local inbox clearing.

Paid, exclusive and unreleased audio remains protected. Tipping is an explicitly labelled browser handoff to the artist’s existing Smashify website page; native payment initiation, grants and financial success claims are not enabled.

## Screenshots

These are real user-provided0.2.9 screenshots. The0.2.10 release changes build type/version, not this interface. System status bars were cropped; the Home greeting name was visibly redacted for privacy. They are not fabricated device-test evidence.

![Home — greeting name redacted](screenshots/home.jpg)
![Discover](screenshots/discover.jpg)
![Offline Library](screenshots/offline-library.jpg)
![Moto artwork-led discovery](screenshots/moto.jpg)

## Privacy and permissions

Music/audio access is optional and needed to list Android-indexed local music. Local files are not uploaded. Saved online music occupies app-private device storage and is not exported to public Downloads. Private storage is not extraction-proof DRM. Sessions use Android Keystore-backed encryption. Existing backup exclusions remain enabled. The local crash report is not uploaded automatically; sharing it is user initiated.

Website: https://smashifymusic.vercel.app/

Privacy policy: https://smashifymusic.vercel.app/privacy

This repository is for binary releases and listing assets. No source-code license or rights to artists’ recordings are granted by these downloads. Artists’ recordings and artwork retain their respective owners’ rights.
