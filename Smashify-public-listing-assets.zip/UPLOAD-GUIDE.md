# GitHub and Orion submission guide

These files are prepared locally, NOT uploaded or submitted. This environment has no supported authenticated GitHub write connector. Never send your password/token here.

## 1. Test the release APK first

Install `SmashifyMusic-0.2.10-release.apk` over your current compatible app, without uninstalling or clearing data. Check opening/Home, retained sign-in/private songs, playback/background controls, Moto and navigation. This is a new optimized release build, not the exact debug APK already tested. If it fails, do not publish; reopen/copy any local crash report.

## 2. Upload public listing files to the main branch

Open while signed in:

https://github.com/visionarybros/smashify-music-android/upload/main

Extract the listing-assets ZIP first. Upload README.md, smashify-icon.png, smashify-icon.svg and the screenshots folder, preserving filenames. If your mobile browser cannot upload a folder, create the screenshots folder in GitHub and upload its four images inside it. Commit the files to main. Do not upload this guide, source ZIP, signing keys/configuration/passwords or diagnostic evidence.

The README replaces the empty initial README. No open-source license is being assigned automatically.

## 3. Create a release — only after phone confirmation

Open:

https://github.com/visionarybros/smashify-music-android/releases/new

- Create tag: v0.2.10
- Target branch: main
- Title: Smashify Music0.2.10
- Description: paste RELEASE_NOTES.md; update its test-status sentence with your actual release-APK result, not just the earlier debug test.
- Attach: SmashifyMusic-0.2.10-release.apk and release-SHA256SUMS.txt.
- Save as draft while testing. Publish only after confirming the actual release APK works. If deliberately publishing as a pre-release, check that Orion/Obtainium accepts pre-releases; do not assume its default feed includes them.

Do not upload source/signing material just to host the APK. If Orion requires open-source licensing, inspect its actual rules first; a public binary repository alone does not establish compliance.

## 4. Verify public URLs after committing/publishing

Repository / Direct Repo:
https://github.com/visionarybros/smashify-music-android

Official icon:
https://raw.githubusercontent.com/visionarybros/smashify-music-android/main/smashify-icon.png

Screenshots (four real images; form requires at least three):
https://raw.githubusercontent.com/visionarybros/smashify-music-android/main/screenshots/home.jpg
https://raw.githubusercontent.com/visionarybros/smashify-music-android/main/screenshots/discover.jpg
https://raw.githubusercontent.com/visionarybros/smashify-music-android/main/screenshots/offline-library.jpg
https://raw.githubusercontent.com/visionarybros/smashify-music-android/main/screenshots/moto.jpg

Release:
https://github.com/visionarybros/smashify-music-android/releases/tag/v0.2.10

APK:
https://github.com/visionarybros/smashify-music-android/releases/download/v0.2.10/SmashifyMusic-0.2.10-release.apk

These are planned destinations, not verified live links until you upload/publish them. Open each image URL and download the APK in a signed-out/private browser window before using Orion.

## 5. Orion form

- Choose Direct Repo, not a fabricated Obtainium JSON export.
- Repo URL: use the repository URL above, WITHOUT .git.
- Icon URL: raw PNG URL above.
- Release keyword: `-release.apk` if this field filters asset filenames. Leave optional filters blank if Orion’s instructions say otherwise; one universal APK is provided.
- Description: paste DESCRIPTION.txt.
- Screenshot URLs: add each raw URL separately with the + button.
- Generate Request opens a pre-filled GitHub issue per the form screenshot. Review it, then submit it manually. It does not guarantee publication or store approval.

Orion’s exact policy/submission URL has not been supplied, so source-license, content and other store requirements are not verified. Send the actual store/submission link or any validation error if more details are needed.

## Private signing safety

The original signing key is preserved. A separate copy of the SAME private key has a strong generated password and private filesystem permissions; it signs the non-debug release. The certificate identity remains the historical development identity—this is not a newly named certificate, because changing certificates would break ordinary update compatibility. Protecting the key file is important, regardless of the certificate label.

Private signing material is retained outside this public folder and outside the source archive. The APK contains the public certificate, not the private signing key/password. Keep a secure owner-controlled offline backup of the private key and its password separately; arrange private backup before relying on public releases. Do not commit either to GitHub, even to a private repository. Losing the key can prevent future updates.
